# DAOT Limbs (addon for Danny's AOT)

Fabric mod, Minecraft 1.21.1, Java 21. Needs Danny's AOT.

- G: shifter heal menu (Arm / Leg / Eyes / Hearts). Bandage: anyone, limbs only.
- Food healing works normally; a shifter's own regeneration is OFF (only Hearts heals them).
- In a titan: hold Shift 5 seconds to smoke away your titan and climb out. In a Colossal, pressing E does it at once with a huge cloud of smoke.
- Cart Titan decay: 4 s -> flesh model, +3 s -> bone model, +3 s -> gone.
- Beast Titan in ice biomes: picks up ice, throws weaker ice rocks, ability #2 carries ice that melts after 2 s.
- First join: you start in a random city of the Paradise dimension (dannys-aot:paradis) with a chest of ODM gear and 4 spare blades.
- First time near a titan: screen shakes, tints red, and you beg in chat.
- Past all the walls of Paradise: ice biome (snow and ice ground).
- Scouts (Paradise only): 100 skins per regiment (Survey Corps, Garrison, Military Police), random personality and name,
  87% Eldian / 10% Ackerman / 3% royal. They carry ODM gear and two blades. Sneak + right-click shows who they are.
- Talk to them by typing in chat: the nearest scout (or the one whose name you type) answers a moment later. Try "hello", "how are you",
  "what's your name", "tell me about the walls", "do you have ODM gear", "are you a titan?".
- Scouts also talk to each other when you are near.
- Elders (15% of scouts, name starts with "Elder"): 40% of them hold one of the nine titan powers, 60% of those hide it.
  Ask a hiding elder in chat, listen for hints, or wait for a titan to show up - they may slip. Their power is only chat/role-play for now
  (they do not turn into titans).

Everything tunable: LimbConfig.java. Test commands (op): /daot shifter lose|regrow|limbs|eyemenu ...
- First time you turn into a titan: 10% you control it and are called a master, 90% it will not obey you for 15 s. (/daot shifter firsttransform to test again)
