package dev.daotlimbs;

import dev.daotlimbs.net.LimbNet;
import dev.daotlimbs.scout.LimbEntities;
import dev.daotlimbs.scout.ScoutChat;
import dev.daotlimbs.scout.ScoutSpawner;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DaotLimbs implements ModInitializer {
    public static final String MOD_ID = "daot_limbs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Touch the attachment type early so it registers before worlds load.
        LimbData.LOST.identifier();
        LimbBlocks.register();
        LimbItems.register();
        LimbEntities.register();

        PayloadTypeRegistry.playS2C().register(LimbNet.SyncPayload.ID, LimbNet.SyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LimbNet.OpenMenuPayload.ID, LimbNet.OpenMenuPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LimbNet.GrowPayload.ID, LimbNet.GrowPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LimbNet.FearPayload.ID, LimbNet.FearPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LimbNet.EyeMenuPayload.ID, LimbNet.EyeMenuPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LimbNet.SpotsPayload.ID, LimbNet.SpotsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LimbNet.EyeSpotPayload.ID, LimbNet.EyeSpotPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LimbNet.EjectPayload.ID, LimbNet.EjectPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LimbNet.OpenRequestPayload.ID, LimbNet.OpenRequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(LimbNet.RegrowPayload.ID, LimbNet.RegrowPayload.CODEC);

        // Key pressed -> shifters get the menu, everyone else gets told no.
        ServerPlayNetworking.registerGlobalReceiver(LimbNet.OpenRequestPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> {
                    ServerPlayerEntity p = ctx.player();
                    if (!DaotBridge.isShifter(p)) {
                        p.sendMessage(Text.literal("Only titan shifters can regrow limbs.").formatted(Formatting.GRAY), true);
                    } else if (LimbData.get(p) == 0 && !LimbManager.isHurt(p)) {
                        p.sendMessage(Text.literal("You are not missing anything.").formatted(Formatting.GRAY), true);
                    } else {
                        ServerPlayNetworking.send(p, new LimbNet.OpenMenuPayload(LimbData.get(p), LimbManager.isHurt(p)));
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(LimbNet.RegrowPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> {
                    ServerPlayerEntity p = ctx.player();
                    Limb.Group[] groups = Limb.Group.values();
                    String err;
                    if (payload.group() == groups.length) {            // the extra menu entry = hearts
                        err = LimbManager.startHeal(p);
                    } else if (payload.group() < 0 || payload.group() > groups.length) {
                        return;
                    } else {
                        err = LimbManager.startRegrow(p, groups[payload.group()]);
                    }
                    if (err != null) p.sendMessage(Text.literal(err).formatted(Formatting.GRAY), true);
                }));

        ServerPlayNetworking.registerGlobalReceiver(LimbNet.EyeSpotPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> LimbManager.setEyeSpot(ctx.player(), payload.limb(), payload.x10(), payload.y10())));

        ServerPlayNetworking.registerGlobalReceiver(LimbNet.EjectPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> TitanEscape.eject(ctx.player())));

        // no hands, no digging
        net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !(player instanceof ServerPlayerEntity sp && !sp.isCreative() && LimbManager.bothArmsGone(sp)));

        // Damage -> maybe lose something. Works for hits on the player and for hits on the shifter's titan body.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // thrown ice hits softer than stone
            Entity hitBy = source.getSource();
            if (hitBy != null && !IceRocks.reapplying && hitBy.getCommandTags().contains(IceRocks.TAG)) {
                IceRocks.reapplying = true;
                try {
                    entity.damage(source, amount * LimbConfig.ICE_DAMAGE_FACTOR);
                } finally {
                    IceRocks.reapplying = false;
                }
                return false;
            }
            if (entity instanceof ServerPlayerEntity p) {
                LimbManager.onHurt(p, source, amount, DaotBridge.ridingTitan(p) != null);
            } else if (DaotBridge.isShifterTitan(entity)) {
                ServerPlayerEntity owner = DaotBridge.shifterOf(entity, entity.getServer());
                if (owner != null) LimbManager.onHurt(owner, source, amount, true);
            }
            return true; // never cancels damage
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity p) LimbManager.onDeath(p);
        });

        ServerTickEvents.END_SERVER_TICK.register(LimbManager::tick);
        ServerTickEvents.END_SERVER_TICK.register(ShiftBoost::tick);
        ServerTickEvents.END_SERVER_TICK.register(TitanEscape::tick);
        TitanDecay.init();
        IceRocks.init();
        FirstSpawn.init();
        IceBiomeZone.init();
        ServerTickEvents.END_SERVER_TICK.register(FearEvents::tick);
        ServerTickEvents.END_SERVER_TICK.register(FirstTransform::tick);
        ServerTickEvents.END_SERVER_TICK.register(ScoutSpawner::tick);
        ServerTickEvents.END_SERVER_TICK.register(ScoutChat::tick);
        ServerMessageEvents.CHAT_MESSAGE.register(ScoutChat::onChat);      // talk to scouts by typing in chat
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ScoutChat.clear());
        LimbVisuals.init();

        // Keep clients' copies of everyone's limb state in sync.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> LimbManager.sync(handler.getPlayer()));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> { LimbManager.onDisconnect(handler.getPlayer().getUuid()); FirstTransform.forget(handler.getPlayer().getUuid()); });
        EntityTrackingEvents.START_TRACKING.register((Entity tracked, ServerPlayerEntity viewer) -> {
            if (tracked instanceof ServerPlayerEntity sp && LimbManager.syncMask(sp) != 0) {
                ServerPlayNetworking.send(viewer, new LimbNet.SyncPayload(sp.getId(), LimbManager.syncMask(sp)));
                LimbManager.sendSpots(sp, viewer);
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> LimbCommands.register(dispatcher));

        LOGGER.info("DAOT Limbs loaded.");
    }
}
