package dev.daotlimbs;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Lets exactly one "leave the titan" call through: the one our 5-second Shift hold makes. */
public final class HoldGate {
    private HoldGate() {}

    private static final Set<UUID> ALLOWED = new HashSet<>();

    public static void allow(ServerPlayerEntity p) { ALLOWED.add(p.getUuid()); }

    public static boolean consume(ServerPlayerEntity p) { return ALLOWED.remove(p.getUuid()); }

    public static void clear(ServerPlayerEntity p) { ALLOWED.remove(p.getUuid()); }
}
