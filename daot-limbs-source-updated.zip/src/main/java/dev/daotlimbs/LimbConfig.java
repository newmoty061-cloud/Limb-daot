package dev.daotlimbs;

/** All tunables in one place. Edit and rebuild. */
public final class LimbConfig {
    private LimbConfig() {}

    // ---- bleeding ----
    public static final int BLEED_TICKS = 20 * 30;          // how long a fresh wound visibly bleeds

    // ---- shifter regrowth (ticks) ----
    public static final int REGEN_SMOKE = 30;               // blood stops, smoke pours out
    public static final int REGEN_BONE = 60;                // bone grows
    public static final int REGEN_FLESH = 60;               // flesh grows over bone
    public static final int REGEN_SKIN = 40;                // skin closes over flesh
    public static final int EYE_REGEN_TICKS = 60;           // blood stops -> smoke -> flash, you can see again

    // ---- how limbs get lost from damage (checked on every hit) ----
    public static final float TITAN_HIT_MIN = 6f;           // hit by any dannys-aot entity (titans, shifters...)
    public static final float TITAN_FORM_MIN = 10f;         // same, but while the victim is in titan form
    public static final double TITAN_HIT_CHANCE = 0.30;
    public static final float BLADE_HIT_MIN = 2f;           // hit by someone holding a dannys-aot blade
    public static final double BLADE_HIT_CHANCE = 0.25;
    public static final float EXPLOSION_HIT_MIN = 8f;
    public static final double EXPLOSION_HIT_CHANCE = 0.30;
    public static final float FALL_MIN = 12f;               // big falls can break (take) a leg
    public static final double FALL_LEG_CHANCE = 0.40;
    public static final float OTHER_HIT_MIN = 14f;          // any other very big hit
    public static final double OTHER_BIG_HIT_CHANCE = 0.15;
    public static final float HEAD_MIN = 14f;               // huge titan hit can take the head
    public static final double HEAD_CHANCE = 0.08;
    public static final int MIN_TICKS_BETWEEN_LOSSES = 20;

    // ---- injured shifting ----
    public static final float SHIFT_FACTOR_ONE_LIMB = 0.6f; // pre-shift time multiplier with 1 arm/leg missing
    public static final float SHIFT_FACTOR_MANY_LIMBS = 0.4f;

    // ---- titan body decay ----
    public static final int DECAY_TICKS = 120;
    public static final boolean DECAY_PURE_TITANS = true;

    // ---- legs / arms ----
    public static final double ONE_LEG_SPEED = -0.55;       // walking speed change with one leg gone (two legs = cannot walk)
    public static final boolean RIGHT_ARM_BLOCKS_MAINHAND = true; // no right arm: whatever you hold in your main hand falls off
    public static final boolean LEFT_ARM_BLOCKS_OFFHAND = true;   // no left arm: whatever is in your off-hand falls off

    // ---- hearts ----
    public static final boolean BLOCK_ALL_HEALING = false;      // players' hearts NEVER heal unless they use the Hearts option (potions, golden apples, regeneration... all blocked)
    public static final boolean DISABLE_NATURAL_REGEN = false;  // food-based healing works normally   // food-based healing is blocked; heal with the G menu instead
    public static final int HEART_STEP_TICKS = 5;               // heal a step every N ticks...
    public static final float HEART_STEP_FRACTION = 0.05f;      // ...of this fraction of max health (20 steps = about 5 seconds)

    // ---- falling when legs are lost ----
    public static final int LEG_FALL_TICKS = 40;               // losing ANY leg knocks you flat for this long; losing both keeps you down

    // ---- swimming and breaking blocks ----
    public static final double SWIM_ARM_PENALTY = 0.2;          // swimming speed lost per missing arm
    public static final double FACEPLANT_PUSH = 0.4;            // how hard you topple forward when the second leg goes

    // ---- first transformation ----
    public static final double FIRST_TRANSFORM_MASTER_CHANCE = 0.10;   // 10% you control it at once and are called a master; 90% you cannot
    public static final int LOST_CONTROL_TICKS = 300;                  // 15 s of the titan not obeying you

    // ---- colossal escape ----
    public static final boolean HOLD_TO_LEAVE_TITAN = true;     // the normal transform key can NOT take you out of a titan; only holding Shift can
    public static final int RELEASE_HOLD_TICKS = 100;           // hold Shift this long (5 s) to smoke away your titan and get out
    public static final int ESCAPE_STEAM_PER_BURST = 40;

    public static final boolean BLOCK_SHIFTER_REGEN = true;     // a titan shifter's own (DAOT) regeneration is OFF; only the Hearts option heals

    // ---- Cart Titan decay timeline (ticks after you leave the body / it dies) ----
    public static final int CART_FLESH_AT_TICKS = 80;           // 4 s  -> flesh model
    public static final int CART_BONE_AT_TICKS = 140;           // +3 s -> bone model
    public static final int CART_END_TICKS = 200;               // +3 s -> gone

    // ---- Beast Titan in ice biomes ----
    public static final float ICE_TEMPERATURE_MAX = 0.05f;      // biome temperature at or below this counts as an ice biome
    public static final float ICE_DAMAGE_FACTOR = 0.5f;         // thrown ice does this fraction of a stone's damage
    public static final int ICE_MELT_TICKS = 40;                // ability #2: carried ice melts after 2 s
    public static final boolean ICE_ABILITY2_IS_BIG_ROCK = true; // false = use the fire-rock ability as "ability #2" instead

    // ---- first-time fear ----
    public static final int FEAR_RANGE = 24;
    public static final int FEAR_TICKS = 200;

    // ---- scouts (Paradise only) ----
    public static final int SCOUT_MAX_NEAR = 4;                 // scouts kept around each player
    public static final int SCOUT_SPAWN_CHANCE = 6;             // 1 in N every 5 s while below the max
    public static final int SCOUT_ELDER_PERCENT = 15;           // % of scouts that are elders
    public static final int ELDER_POWER_PERCENT = 40;           // % of elders that hold one of the nine titan powers
    public static final int ELDER_HIDE_PERCENT = 60;            // % of power-holding elders that keep it secret
    public static final int ELDER_SLIP_PERCENT = 30;            // % chance a hiding elder admits it when you ask them in chat
    public static final int SCOUT_CHAT_RANGE = 16;              // blocks: scouts this close hear what you type in chat
    public static final int SCOUT_CHATTER_MIN_TICKS = 400;      // scouts talk to each other every N to 2N ticks (when you are near)

    // ---- head loss ----
    /** If the shifter's titan body is beheaded (per DAOT's own Decapitation tracking) the shifter dies too. */
    public static final boolean KILL_SHIFTER_WHEN_TITAN_BEHEADED = true;
}
