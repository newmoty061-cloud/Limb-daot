package dev.daotlimbs.scout;

import net.minecraft.util.math.random.Random;

/**
 * Elders, secret titan powers, and every extra line the scouts say when you talk to them in chat or when they talk
 * to each other. Lines containing %s get the titan's name (or an address) filled in.
 */
public final class ScoutLore {
    private ScoutLore() {}

    /** The nine titans of Danny's AOT. */
    public enum Power {
        FOUNDING("Founding Titan"), ATTACK("Attack Titan"), ARMORED("Armored Titan"), COLOSSAL("Colossal Titan"),
        FEMALE("Female Titan"), BEAST("Beast Titan"), CART("Cart Titan"), JAW("Jaw Titan"), WAR_HAMMER("War Hammer Titan");
        public final String title;
        Power(String title) { this.title = title; }
    }

    public static String pick(String[] a, Random r) { return a[r.nextInt(a.length)]; }

    // ---------- someone asks "are you a titan?" ----------
    /** Ordinary scouts. */
    public static final String[] NOT_A_SHIFTER = {
            "Me? A titan? I'm just a scout with a sore back.", "Ha! If I could turn into a titan I'd skip drills.",
            "No. But if anyone around here is hiding something, I'd look at the elders.",
            "Keep your voice down. Rumours about shifters get people dragged away.",
            "I wish. I'd be a lot harder to eat."};
    /** Elder who holds a power and hides it. */
    public static final String[] DENY = {
            "A titan? Me? Have you been out in the sun too long?", "I'm just an old scout. Nothing more. Drop it.",
            "Don't say such things so loudly. Who told you that?", "Hmph. Rumours. Every old soldier gets them.",
            "...I don't know what you're talking about."};
    /** Elder who holds a power and slips (the secret comes out). */
    public static final String[] SLIP = {
            "...Fine. You're sharper than you look. I carry the %s. Tell no one.",
            "How did you know? Yes. The %s is mine. I've hidden it for years.",
            "Quiet! ...Yes. I hold the %s. Now you share the burden."};
    /** Elder who holds a power and does not hide it. */
    public static final String[] ADMIT = {
            "Yes. I carry the %s. Everyone here knows, and nobody speaks of it.",
            "I hold the %s. No use hiding it at my age.",
            "The %s, yes. It is a heavy gift. Thirteen years is not long."};

    // ---------- unprompted ----------
    public static final String[] HINT = {
            "Funny, my hands steam when I'm angry. Must be the cold.", "I've been tired lately. Thirteen years... never mind.",
            "Don't stand too close if I lose my temper. Old habit.", "Some nights I dream I'm much taller than I am.",
            "I heal fast. Too fast. Don't ask."};
    public static final String[] OPEN_AMBIENT = {
            "The %s weighs on me, but I carry it so the young ones don't have to.",
            "If titans come, stay behind me. I am the %s.",
            "Everyone knows what I am. At least there are no secrets left to keep."};
    public static final String[] SLIP_ALARM = {
            "I can't hide it any more. Get back, all of you, I am the %s!",
            "Forgive me. Stand clear. The %s will not let them pass.",
            "Not again... Stay behind me. I carry the %s!"};
    public static final String[] OPEN_ALARM = {
            "Leave this one to me. The %s has been waiting.", "Get back! The %s will handle this."};
    public static final String[] SHOCK = {
            "Wait... you're one of THEM? All this time?", "An elder with a titan power... and nobody knew?!",
            "I never would have guessed. Is it true?", "So the rumours were real..."};

    // ---------- topics when you talk in chat ----------
    public static final String[][] GREET = {
            /* BRAVE */ {"Greetings. Stay sharp out here.", "Hello. Good to see a steady face."},
            /* COWARD */ {"Oh! H-hello. You startled me.", "Hi... is it safe out there?"},
            /* CHEERFUL */ {"Hello, hello! Lovely to see you!", "Hey there! Fine day, isn't it?"},
            /* GRUMPY */ {"Hm. Hello.", "What now? ...Oh. Hello."},
            /* CURIOUS */ {"Hello! Do you have a moment? I have questions.", "Oh, hello! You're new, aren't you?"},
            /* STOIC */ {"Hello.", "Evening."},
            /* HOTHEADED */ {"Yeah, hi. Got a titan for me?", "Hey! Finally, someone worth talking to."},
            /* KIND */ {"Hello, friend. Are you well?", "Hi there. Glad you're safe."}
    };
    public static final String[][] HOW_ARE_YOU = {
            /* BRAVE */ {"Ready for anything."}, /* COWARD */ {"Terrified, but alive."},
            /* CHEERFUL */ {"Wonderful! Why wouldn't I be?"}, /* GRUMPY */ {"Tired. Wet. Annoyed."},
            /* CURIOUS */ {"Busy thinking. And you?"}, /* STOIC */ {"Fine."},
            /* HOTHEADED */ {"Restless. I want a fight."}, /* KIND */ {"I'm well, thank you for asking."}
    };
    public static final String[] GEAR = {
            "My ODM gear is cleaned and oiled every morning. It's the only thing between me and a titan's mouth.",
            "Two blades, a harness and a full gas tank. That's all we've got.",
            "Keep your gas canisters full and your blades sharp. Everything else is luck.",
            "Don't ever trust a blade you haven't checked yourself."};
    public static final String[] WALL = {
            "Three walls, and every one of them is older than anyone remembers.",
            "People say the walls will stand forever. I stopped believing that long ago.",
            "Maria, Rose, Sina. We live and die by their height."};
    public static final String[] THANKS = {"Anytime.", "Don't mention it.", "Glad to help.", "That's what scouts are for."};
    public static final String[] HELP = {
            "Stay close to me. We'll get through it.", "Tell me where and I'll cover you.", "Run if you have to. I'll follow."};
    public static final String[] WHO_AM_I = {"I'm %s of the %s.", "They call me %s. %s, if it matters."};

    // ---------- scouts talking to each other ----------
    public static final String[] TO_COLLEAGUE = {
            "did you check your gas this morning?", "heard anything from the other patrols?",
            "I swear the titans are getting bolder.", "think we'll get relieved before dark?",
            "have you eaten? I saved some bread.", "quiet day. I don't trust it.",
            "my blades need replacing again.", "did you see that? Something moved by the wall."};
    public static final String[][] REPLY = {
            /* BRAVE */ {"Of course. Always.", "Let them come.", "We hold the line, same as ever."},
            /* COWARD */ {"Please don't say things like that...", "Oh no. Oh no no no.", "I'd rather not think about it."},
            /* CHEERFUL */ {"Ha! We'll manage.", "Bread? Yes please!", "It's fine! Everything is fine!"},
            /* GRUMPY */ {"Not my problem.", "Keep it down.", "Hmph. Obviously."},
            /* CURIOUS */ {"Interesting. Why do you ask?", "I've been wondering that myself.", "Let's write that down."},
            /* STOIC */ {"Hm.", "Noted.", "Yes."},
            /* HOTHEADED */ {"Good! Bring it on!", "I'm sick of waiting around.", "Say the word and I'm gone."},
            /* KIND */ {"I'll look out for you.", "Thank you for asking. Truly.", "Let's stay together, all right?"}
    };
    /** One scout whispers to an elder they suspect. */
    public static final String[] RUMOUR_TO_ELDER = {
            "Elder, forgive me, but there's talk that you're one of... them.",
            "Elder, people say you haven't aged like the rest of us. Is it true?",
            "Elder, tell me honestly. Do you carry a titan?"};
    /** An elder with an open secret is asked to speak about it. */
    public static final String[] ASK_ELDER = {
            "Elder, tell the young ones again what you carry.", "Elder, how do you bear it?"};
}
