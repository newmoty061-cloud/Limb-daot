package dev.daotlimbs.scout;

import dev.daotlimbs.LimbConfig;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Lets you talk to scouts by typing in chat: the nearest one (or the one whose name you say) answers a moment later.
 * Also holds the small delayed-task queue the scouts use to answer each other.
 */
public final class ScoutChat {
    private ScoutChat() {}

    private record Task(long due, Runnable run) {}

    private static final List<Task> TASKS = new ArrayList<>();

    /** Run something after a delay (ticks). */
    public static void later(MinecraftServer server, int delayTicks, Runnable r) {
        TASKS.add(new Task(server.getTicks() + delayTicks, r));
    }

    public static void clear() { TASKS.clear(); }

    public static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) return;
        long now = server.getTicks();
        List<Runnable> due = new ArrayList<>();
        for (var it = TASKS.iterator(); it.hasNext(); ) {
            Task t = it.next();
            if (t.due() <= now) { due.add(t.run()); it.remove(); }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (Throwable ignored) { }
        }
    }

    /** Hooked to Fabric's CHAT_MESSAGE event. */
    public static void onChat(SignedMessage message, ServerPlayerEntity sender, MessageType.Parameters params) {
        MinecraftServer server = sender.getServer();
        if (server == null || ScoutEntity.TYPE == null) return;
        String text = message.getSignedContent();
        server.execute(() -> handle(server, sender, text));
    }

    private static void handle(MinecraftServer server, ServerPlayerEntity sender, String text) {
        ServerWorld w = sender.getServerWorld();
        List<ScoutEntity> near = new ArrayList<>(w.getEntitiesByType(ScoutEntity.TYPE,
                sender.getBoundingBox().expand(LimbConfig.SCOUT_CHAT_RANGE), ScoutEntity::isAlive));
        if (near.isEmpty()) return;
        near.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(sender)));

        String lower = text.toLowerCase(Locale.ROOT);
        Set<String> words = new HashSet<>();
        for (String s : lower.split("[^a-z]+")) if (!s.isEmpty()) words.add(s);

        List<ScoutEntity> responders = new ArrayList<>();
        for (ScoutEntity s : near) if (s.isAddressedBy(words)) { responders.add(s); break; }
        if (responders.isEmpty()) {
            responders.add(near.get(0));
            if (near.size() > 1 && sender.getRandom().nextInt(2) == 0) responders.add(near.get(1));
        }

        int i = 0;
        for (ScoutEntity s : responders) {
            final ScoutEntity scout = s;
            int delay = 25 + i * 35 + sender.getRandom().nextInt(20);
            i++;
            scout.getLookControl().lookAt(sender);
            later(server, delay, () -> {
                if (scout.isRemoved() || !scout.isAlive()) return;
                scout.broadcast(scout.replyToChat(lower, words), 24);
            });
        }
    }
}
