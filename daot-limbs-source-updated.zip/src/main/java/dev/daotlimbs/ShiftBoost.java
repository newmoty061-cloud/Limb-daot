package dev.daotlimbs;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;
import java.util.*;

/**
 * Injured shifters transform faster. DAOT queues a transformation in a private static map of immutable
 * PendingShift records with a countdown (ticksRemaining). The first tick we see a new entry for an injured
 * player we swap in an identical record with a shorter countdown. Done reflectively; if DAOT changes this
 * shape, a warning is logged once and the feature simply does nothing.
 */
public final class ShiftBoost {
    private ShiftBoost() {}

    private static final Set<Object> HANDLED = new HashSet<>();

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void tick(MinecraftServer server) {
        Map map = DaotBridge.pendingShifts();
        if (map == null) return;
        if (map.isEmpty()) { HANDLED.clear(); return; }
        HANDLED.retainAll(new HashSet<>(map.keySet()));

        for (Object o : new ArrayList<>(map.entrySet())) {
            Map.Entry e = (Map.Entry) o;
            Object key = e.getKey();
            if (!HANDLED.add(key)) continue;

            ServerPlayerEntity p = playerFor(server, key);
            if (p == null) continue;
            int missing = Integer.bitCount(LimbManager.armLegLost(p));
            if (missing == 0) continue;

            float factor = missing == 1 ? LimbConfig.SHIFT_FACTOR_ONE_LIMB : LimbConfig.SHIFT_FACTOR_MANY_LIMBS;
            Object faster = withShorterCountdown(e.getValue(), factor);
            if (faster != null) {
                map.put(key, faster);
                p.sendMessage(net.minecraft.text.Text.literal("Your wounds force the change...").formatted(net.minecraft.util.Formatting.RED), true);
            }
        }
    }

    private static ServerPlayerEntity playerFor(MinecraftServer s, Object key) {
        if (key instanceof UUID id) return s.getPlayerManager().getPlayer(id);
        if (key instanceof ServerPlayerEntity sp) return sp;
        if (key instanceof Integer eid) {
            for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) if (p.getId() == eid) return p;
        }
        return null;
    }

    private static Object withShorterCountdown(Object rec, float factor) {
        if (rec == null || !rec.getClass().isRecord()) return null;
        try {
            RecordComponent[] comps = rec.getClass().getRecordComponents();
            Class<?>[] types = new Class<?>[comps.length];
            Object[] args = new Object[comps.length];
            boolean changed = false;
            for (int i = 0; i < comps.length; i++) {
                types[i] = comps[i].getType();
                var acc = comps[i].getAccessor();
                acc.setAccessible(true);
                args[i] = acc.invoke(rec);
                if (comps[i].getName().equals("ticksRemaining") && args[i] instanceof Integer t) {
                    args[i] = Math.max(1, (int) (t * factor));
                    changed = true;
                }
            }
            if (!changed) return null;
            Constructor<?> c = rec.getClass().getDeclaredConstructor(types);
            c.setAccessible(true);
            return c.newInstance(args);
        } catch (Throwable t) {
            DaotLimbs.LOGGER.warn("[daot_limbs] Could not speed up shift: {}", t.toString());
            return null;
        }
    }
}
