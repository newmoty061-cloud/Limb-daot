package dev.daotlimbs.net;

import dev.daotlimbs.DaotLimbs;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public final class LimbNet {
    private LimbNet() {}

    private static <T extends CustomPayload> CustomPayload.Id<T> id(String path) {
        return new CustomPayload.Id<>(Identifier.of(DaotLimbs.MOD_ID, path));
    }

    /** S2C: this entity's lost-limb mask changed. */
    public record SyncPayload(int entityId, int mask) implements CustomPayload {
        public static final Id<SyncPayload> ID = id("sync");
        public static final PacketCodec<RegistryByteBuf, SyncPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, SyncPayload::entityId,
                PacketCodecs.VAR_INT, SyncPayload::mask,
                SyncPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: how far the real (skin) limb has grown back, 0..1. Drives the model scale on clients. */
    public record GrowPayload(int entityId, int limb, float progress) implements CustomPayload {
        public static final Id<GrowPayload> ID = id("grow");
        public static final PacketCodec<RegistryByteBuf, GrowPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, GrowPayload::entityId,
                PacketCodecs.VAR_INT, GrowPayload::limb,
                PacketCodecs.FLOAT, GrowPayload::progress,
                GrowPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: first eye loss ever, open the "where is the hollow" menu. limb = ordinal of the lost eye. */
    public record EyeMenuPayload(int limb) implements CustomPayload {
        public static final Id<EyeMenuPayload> ID = id("eye_menu");
        public static final PacketCodec<RegistryByteBuf, EyeMenuPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, EyeMenuPayload::limb,
                EyeMenuPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: where this player's hollow eyes sit on the face (x10 / y10 in face pixels). */
    public record SpotsPayload(int entityId, int lx, int ly, int rx, int ry) implements CustomPayload {
        public static final Id<SpotsPayload> ID = id("spots");
        public static final PacketCodec<RegistryByteBuf, SpotsPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, SpotsPayload::entityId,
                PacketCodecs.VAR_INT, SpotsPayload::lx,
                PacketCodecs.VAR_INT, SpotsPayload::ly,
                PacketCodecs.VAR_INT, SpotsPayload::rx,
                PacketCodecs.VAR_INT, SpotsPayload::ry,
                SpotsPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** C2S: the player tapped the face where the hollow should be. */
    public record EyeSpotPayload(int limb, int x10, int y10) implements CustomPayload {
        public static final Id<EyeSpotPayload> ID = id("eye_spot");
        public static final PacketCodec<RegistryByteBuf, EyeSpotPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, EyeSpotPayload::limb,
                PacketCodecs.VAR_INT, EyeSpotPayload::x10,
                PacketCodecs.VAR_INT, EyeSpotPayload::y10,
                EyeSpotPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: first time near a titan: shake the screen and tint it red for this many ticks. */
    public record FearPayload(int ticks) implements CustomPayload {
        public static final Id<FearPayload> ID = id("fear");
        public static final PacketCodec<RegistryByteBuf, FearPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, FearPayload::ticks,
                FearPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** C2S: the player pressed E while inside a Colossal Titan. */
    public record EjectPayload() implements CustomPayload {
        public static final Id<EjectPayload> ID = id("eject");
        public static final PacketCodec<RegistryByteBuf, EjectPayload> CODEC = PacketCodec.unit(new EjectPayload());
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** C2S: player pressed the regrow key. */
    public record OpenRequestPayload() implements CustomPayload {
        public static final Id<OpenRequestPayload> ID = id("open_request");
        public static final PacketCodec<RegistryByteBuf, OpenRequestPayload> CODEC =
                PacketCodec.unit(new OpenRequestPayload());
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: server confirmed the player is a shifter; open the menu. */
    public record OpenMenuPayload(int mask, boolean hurt) implements CustomPayload {
        public static final Id<OpenMenuPayload> ID = id("open_menu");
        public static final PacketCodec<RegistryByteBuf, OpenMenuPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, OpenMenuPayload::mask,
                PacketCodecs.BOOL, OpenMenuPayload::hurt,
                OpenMenuPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** C2S: player chose a group in the menu (ordinal of Limb.Group). */
    public record RegrowPayload(int group) implements CustomPayload {
        public static final Id<RegrowPayload> ID = id("regrow");
        public static final PacketCodec<RegistryByteBuf, RegrowPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, RegrowPayload::group,
                RegrowPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }
}
