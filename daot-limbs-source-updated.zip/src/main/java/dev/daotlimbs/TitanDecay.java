package dev.daotlimbs;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * When a shifter titan dies or its shifter climbs out, the body smokes and wastes away:
 * skin -> flesh -> bone -> gone (Colossal has no skin: flesh -> bone -> gone).
 * Visuals are particles (the 3D model itself is not re-textured); the entity is removed at the end.
 */
public final class TitanDecay {
    private TitanDecay() {}

    private static final class Track {
        final Entity e;
        int age = -1;                 // -1 = not decaying yet
        List<Entity> flesh;           // Cart Titan only: flesh model, then bone model
        List<Entity> bone;
        Track(Entity e) { this.e = e; }
    }

    private static final Map<UUID, Track> TRACKED = new HashMap<>();

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register((e, w) -> {
            if (shouldTrack(e)) TRACKED.putIfAbsent(e.getUuid(), new Track(e));
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((e, w) -> {
            Track t = TRACKED.get(e.getUuid());
            if (t != null && t.age < 0) TRACKED.remove(e.getUuid());
        });
        ServerTickEvents.END_SERVER_TICK.register(TitanDecay::tick);
    }

    private static boolean shouldTrack(Entity e) {
        if (DaotBridge.isShifterTitan(e)) return true;
        return LimbConfig.DECAY_PURE_TITANS && DaotBridge.isPureTitan(e);
    }

    private static void tick(MinecraftServer server) {
        if (TRACKED.isEmpty()) return;
        Iterator<Track> it = TRACKED.values().iterator();
        while (it.hasNext()) {
            Track t = it.next();
            Entity e = t.e;
            if (e.isRemoved() || !(e.getWorld() instanceof ServerWorld w)) {
                LimbVisuals.discardAll(t.flesh);
                LimbVisuals.discardAll(t.bone);
                it.remove();
                continue;
            }

            if (t.age < 0) {
                boolean dead = e instanceof LivingEntity le && (le.isDead() || le.getHealth() <= 0f);
                if (!dead && !DaotBridge.isDismounting(e)) continue;
                t.age = 0;
            }
            t.age++;
            int total = DaotBridge.isCart(e) ? LimbConfig.CART_END_TICKS : LimbConfig.DECAY_TICKS;

            if (t.age % 2 == 0) emit(w, e, t.age, total);
            if (DaotBridge.isCart(e)) cartModels(w, e, t);

            if (t.age >= total) {
                Box b = e.getBoundingBox();
                Fx.far(w, ParticleTypes.POOF, b.getCenter(), 30, Math.min(8, b.getLengthY() / 4), 0.1);
                LimbVisuals.discardAll(t.flesh);
                LimbVisuals.discardAll(t.bone);
                e.discard();
                it.remove();
            }
        }
    }

    /** Cart Titan: skin -> its real flesh model -> its skeleton -> gone. */
    private static void cartModels(ServerWorld w, Entity e, Track t) {
        if (t.age >= LimbConfig.CART_FLESH_AT_TICKS && t.flesh == null) {
            t.flesh = TitanModels.spawn(w, e, "cart_flesh");
        }
        if (t.age >= LimbConfig.CART_BONE_AT_TICKS && t.bone == null) {
            LimbVisuals.discardAll(t.flesh);
            t.bone = TitanModels.spawn(w, e, "cart_bone");
            e.setInvisible(true);                       // the skin model is gone; only bones remain
        }
    }

    private static void emit(ServerWorld w, Entity e, int age, int total) {
        double prog = age / (double) total;
        boolean colossal = DaotBridge.isColossal(e);
        ParticleEffect layer;
        if (colossal) layer = prog < 0.5 ? Fx.bits(LimbBlocks.FLESH) : Fx.bits(LimbBlocks.BONE);
        else layer = prog < 0.34 ? Fx.bits(LimbBlocks.SKIN) : (prog < 0.67 ? Fx.bits(LimbBlocks.FLESH) : Fx.bits(LimbBlocks.BONE));

        Box b = e.getBoundingBox();
        int n = (int) Math.max(6, Math.min(40, b.getAverageSideLength() * 3));
        var rnd = e.getWorld().getRandom();
        for (int i = 0; i < n; i++) {
            Vec3d p = new Vec3d(
                    b.minX + rnd.nextDouble() * b.getLengthX(),
                    b.minY + rnd.nextDouble() * b.getLengthY(),
                    b.minZ + rnd.nextDouble() * b.getLengthZ());
            Fx.far(w, layer, p, 1, 0.1, 0.01);
            if (!colossal && i % 2 == 0) Fx.far(w, Fx.steam(), p, 1, 0.3, 0.03);
        }
        if (colossal) Fx.bodySteam(w, e, 24);
    }
}
