package dev.daotlimbs.mixin;

import dev.daotlimbs.IceBiomeZone;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Danny's AOT Paradise biome source: past all the walls, answer with an ice biome instead.
 * (method_38109 is BiomeSource.getBiome in the runtime names.)
 */
@Mixin(targets = "daot.world.ParadisBiomeSource", remap = false)
public abstract class ParadisBiomeSourceMixin {
    @Inject(method = "method_38109", at = @At("HEAD"), cancellable = true, remap = false)
    private void daotlimbs$iceBeyondTheWalls(int x, int y, int z, MultiNoiseUtil.MultiNoiseSampler sampler,
                                             CallbackInfoReturnable<RegistryEntry<Biome>> cir) {
        RegistryEntry<Biome> ice = IceBiomeZone.biomeFor(x, z);
        if (ice != null) cir.setReturnValue(ice);
    }
}
