package dev.daotlimbs.client;

import dev.daotlimbs.Limb;
import dev.daotlimbs.net.LimbNet;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** "What do you want to heal?" */
public class LimbMenuScreen extends Screen {
    private final int mask;
    private final boolean hurt;

    public LimbMenuScreen(int mask, boolean hurt) {
        super(Text.literal("Regenerate"));
        this.mask = mask;
        this.hurt = hurt;
    }

    @Override
    protected void init() {
        int w = 160, h = 20, x = this.width / 2 - w / 2, y = this.height / 2 - 40;
        int i = 0;
        for (Limb.Group g : Limb.Group.values()) {
            int missing = mask & Limb.maskOf(g);
            String name = switch (g) { case ARM -> "Arm"; case LEG -> "Leg"; case EYES -> "Eyes"; };
            Text label = Text.literal(missing == 0 ? name + " (fine)" : name + "  [" + Limb.describe(missing) + "]");
            addChoice(label, g.ordinal(), missing != 0, x - 40, y + i * 24, w + 80, h);
            i++;
        }
        // extra entry after the limb groups = hearts
        addChoice(Text.literal(hurt ? "Hearts  [hurt]" : "Hearts (full)"), Limb.Group.values().length, hurt, x - 40, y + i * 24, w + 80, h);
    }

    private void addChoice(Text label, int id, boolean active, int x, int y, int w, int h) {
        ButtonWidget b = ButtonWidget.builder(label, btn -> {
            ClientPlayNetworking.send(new LimbNet.RegrowPayload(id));
            this.close();
        }).dimensions(x, y, w, h).build();
        b.active = active;
        this.addDrawableChild(b);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("What do you want to heal?"), this.width / 2, this.height / 2 - 60, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() { return false; }
}
