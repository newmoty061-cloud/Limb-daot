package dev.daotlimbs.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

import java.util.Random;

/** Small screen shake + a slight red tint while the fear scene plays. */
public final class FearClient {
    private FearClient() {}

    private static int ticks = 0;
    private static int total = 1;
    private static float lastYaw = 0f, lastPitch = 0f;
    private static final Random RND = new Random();

    public static void start(int t) { ticks = t; total = Math.max(1, t); }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            var p = client.player;
            if (p == null) { ticks = 0; lastYaw = lastPitch = 0f; return; }
            // undo last tick's nudge so the shake never moves your aim for good
            if (lastYaw != 0f || lastPitch != 0f) {
                p.setYaw(p.getYaw() - lastYaw);
                p.setPitch(p.getPitch() - lastPitch);
                lastYaw = lastPitch = 0f;
            }
            if (ticks <= 0) return;
            ticks--;
            float fade = Math.min(1f, ticks / (total * 0.35f));          // eases out over the last third
            lastYaw = (RND.nextFloat() - 0.5f) * 1.1f * fade;
            lastPitch = (RND.nextFloat() - 0.5f) * 0.9f * fade;
            p.setYaw(p.getYaw() + lastYaw);
            p.setPitch(p.getPitch() + lastPitch);
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            if (ticks <= 0) return;
            MinecraftClient c = MinecraftClient.getInstance();
            float fade = Math.min(1f, ticks / (total * 0.35f));
            float pulse = 0.75f + 0.25f * (float) Math.sin((total - ticks) * 0.5);
            int alpha = (int) (60 * fade * pulse);
            ctx.fill(0, 0, c.getWindow().getScaledWidth(), c.getWindow().getScaledHeight(), (alpha << 24) | 0xB00000);
        });
    }
}
